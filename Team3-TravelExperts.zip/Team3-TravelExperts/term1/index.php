<?php
  header("Location: Template/Group Website/index.php");
 ?>
