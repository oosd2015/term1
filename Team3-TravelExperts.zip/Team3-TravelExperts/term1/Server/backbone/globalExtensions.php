<?php
/****************************************************************************
Title:       Global Extensions
Author:      Dylan Harty and Heidi Cantalejo (pairProgramming)
Class:       OOSD FALL 2015
Date:        2015-11-18
Description: This file is to be included in global.php to define global
              variables.
*****************************************************************************/
define("DATABASE_HOST","localhost");

define("DATABASE_TRAVELEXPERTS","travelexperts");
define("DATABASE_TRAVELEXPERTS_USERNAME",'root');
define("DATABASE_TRAVELEXPERTS_PASSWORD",'');

//MYSQL CONNECTION ERRORS
define("DATABASE_QUERY_ERROR","1000");

 ?>
