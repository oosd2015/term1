<footer>
  <div class="container">
    <div class="row">
      <div class="col-lg-8 col-lg-offset-2 text-center" style="margin-top:2em">
        <p><strong>Copyright 2015 OOSD Travel Experts</strong></p>
      </div>
    </div>
  </div>
</footer>
