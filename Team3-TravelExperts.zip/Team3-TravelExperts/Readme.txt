TEAM #3-------------------------------------------------------------------------

This folder contains the project Travel Experts webpage  for Team 3#
 - Dylan, Deya, Heidi, Royal

We have made a specific database, please import before testing,
otherwise functionality such as registration, login and packages will not work!
Thank you.

There are a number of files that pertain to bootstrap and jquery that were not
written by our team, these have been cited where appropriate.

Group files and Authors---------------------------------------------------------
index.php - Royal
Server/backbone/global.php - Dylan
Server/backbone/globalExensions.php - Dylan
Server/backbone/modules/agencies.inc.php - Royal and Deya
Server/backbone/modules/customers.inc.php - Royal and Deya
Server/backbone/modules/form.inc.php - Royal
Server/backbone/modules/login.inc.php - Royal and Deya
Server/backbone/modules/packages.inc.php - Dylan and Heidi
Server/backbone/modules/querystr.inc.php - Royal
Server/backbone/modules/registration.inc.php - Royal
Template/Group website/css/customStyle.css - Deya and Dylan
Template/Group website/js/form.js - Royal
Template/Group website/bookings.php - Dylan and Heidi
Template/Group website/contact.php - Deya
Template/Group website/footer.php - Deya
Template/Group website/index.php - Deya
Template/Group website/login.php - Royal and Deya
Template/Group website/logout.php - Royal and Deya
Template/Group website/orderNow.php - Dylan and Heidi
Template/Group website/packages.php - Dylan and Heidi
Template/Group website/plane.php - Royal
Template/Group website/receipt.php - Dylan and Heidi
Template/Group website/registration.php - Royal and Deya
-------------------------------------------------------------------------------